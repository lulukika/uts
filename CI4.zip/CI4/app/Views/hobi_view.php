<!DOCTYPE html>
<html>
<head>
	<title>hobi</title>
</head>
<body  <table border="1" cellpading="2" bgcolor="green"> 

<P><?= $Hobi; ?></P>

<p>
	
</body>
</html>