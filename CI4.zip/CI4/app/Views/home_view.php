<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
</head>
<body bgcolor="green">
<?= $index; ?>

</body>
</html>