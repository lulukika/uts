<!DOCTYPE html>
<html>
<head>
	<title>DATA OBAT</title>
</head>
<body>
	<thead>
		<tr>
		<th>kode obat</th>
		<th>kode supplier</th>
		<th>kode detil</th>
		<th>nama obat</th>
		<th>produse</th>
		<th>harga</th>
		<th>jumlah stok</th>
		
	</tr>
	</thead>
	
</body>
</html>