<!DOCTYPE html>
<html>
<head>
	<title>RIWAYAT PENDIDIKAN</title>
</head>
<body <table border="1" cellpading="2" bgcolor="yellow"> 

<?= $riwayat; ?>




</body>
</html>