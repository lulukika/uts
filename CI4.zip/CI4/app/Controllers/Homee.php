<?php
namespace App\Controllers;
class Home extends Basecontroller{
	public function index(){
		return view()
	}
}
?>